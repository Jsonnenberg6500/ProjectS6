<?php
if (isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'Request1':
            insert();
            break;
        case 'Request2':
            select();
            break;
        case 'Request3':
            select();
            break;
    }
}

function select() {
    echo "The select function is called.";
    exit;
}

function insert() {
    echo "The insert function is called.";
    exit;
}
?>
