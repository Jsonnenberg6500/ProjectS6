<?php
function abc(): void{
     echo "It worked"
?>
